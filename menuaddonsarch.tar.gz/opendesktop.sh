#!/bin/bash
/home/mosquito/.local/share/kio/servicemenus/SystemUpdateMenu.desktop
