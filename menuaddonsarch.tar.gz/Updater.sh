#!/bin/bash
echo this will close automatically if theres no updates
echo checking for system and application updates
sudo pacman -Sy --noconfirm
sudo pacman -Syu --noconfirm

