#!/bin/bash
qdbus org.kde.KWin /Session org.kde.KWin.Session.quit
